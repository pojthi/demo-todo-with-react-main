export const Server = {
    endpoint : process.env.REACT_APP_ENDPOINT,
    project: process.env.REACT_APP_PROJECT,
    collectionID : process.env.REACT_APP_COLLECTION_ID
}
